
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:resume_builder/screens/add_information_screen.dart';
import 'package:resume_builder/screens/resumes_data.dart';

class ListScreen extends StatefulWidget {
final String id;
  ListScreen({Key? key, required this.id, }) : super(key: key);

  @override
  State<ListScreen> createState() => _ListScreenState();
}

class _ListScreenState extends State<ListScreen> {
 CollectionReference ref=FirebaseFirestore.instance.collection("users");
  @override
  Widget build(BuildContext context) {

    return Scaffold(  appBar: AppBar(automaticallyImplyLeading: false,centerTitle:true,title: Text("Resumes List",style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.w500),),backgroundColor: Colors.green,),
      floatingActionButton: FloatingActionButton(onPressed: (){
      Navigator.push(context, MaterialPageRoute(builder: (context)=>AddInformation()));
    },child: Icon(Icons.add),),
      body: SafeArea(
      child: Column(crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
        StreamBuilder<QuerySnapshot>(
            stream:FirebaseFirestore.instance.collection("user").doc(widget.id).collection("userdata").snapshots(),
            builder: (BuildContext context,AsyncSnapshot<QuerySnapshot> snapshot){

              if(snapshot.connectionState==ConnectionState.waiting){
                return const Center(child: CircularProgressIndicator(color: Colors.black));
              }
              else if(snapshot.data!.docs.isEmpty)
              {
                return   Center(child: Text(" No Data Found",style:TextStyle(fontSize: 20,fontWeight:FontWeight.w500,color: Colors.grey)));

              }
              else if(snapshot.hasData){
                return  Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: ListView.builder(itemCount:snapshot.data!.docs.length,
                        itemBuilder: (context,index){
                          return InkWell(onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>ResumeData(
                              name: snapshot.data!.docs[index]["name"].toString(),
                               achieve: snapshot.data!.docs[index]["achieve"].toString(),
                               address: snapshot.data!.docs[index]["address"].toString(),
                               designation: snapshot.data!.docs[index]["designation"].toString(),
                               email:snapshot.data!.docs[index]["email"].toString() ,
                               experience: snapshot.data!.docs[index]["exp"].toString(),
                               grad:snapshot.data!.docs[index]["grad"].toString(),
                               phone:snapshot.data!.docs[index]["phone"].toString() ,
                               post:snapshot.data!.docs[index]["postG"].toString() ,
                               project: snapshot.data!.docs[index]["project"].toString(),
                               skill: snapshot.data!.docs[index]["skill"].toString(),


                            )));

                          },
                            child: Card(margin:const EdgeInsets.all(6),child:
                            ListTile(
                              leading:CircleAvatar(radius: 20,
                             child: Text(snapshot.data!.docs[index]["name"][0],style: TextStyle(fontSize: 25),),),
                              title: Text(snapshot.data!.docs[index]["name"],
                                style: const TextStyle(fontWeight: FontWeight.w400,fontSize: 24,color: Colors.black),),
                              subtitle: Text(snapshot.data!.docs[index]["designation"],
                                  style: const TextStyle(fontWeight: FontWeight.w300,fontSize: 20,color: Colors.grey)),
                              trailing: InkWell(onTap: (){
                                showDialog(
                                  barrierDismissible: false,
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: const Text('Are you sure?'),
                                    content:   const Text('You want to delete this data'),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.pop(context),
                                        child:  const Text('Cancel'),
                                      ),
                                      TextButton(
                                        onPressed: () {
                                      deleteTask(snapshot.data!.docs[index].reference);
                                          Navigator.pop(context);
                                        }  ,
                                        child: const Text('Delete'),
                                      ),

                                    ],
                                  ),
                                );

                              },
                                  child: const Icon(Icons.delete)) ,)
                              ,),
                          );
                        }),
                  ),
                );
              }
              else{
                return Text("error");
              }

            }
        )
      ],),
    ), );
  }
 Future<void> deleteTask(DocumentReference reference)async{
   try{
     await reference.delete();
   }
   catch(e){}

 }
}
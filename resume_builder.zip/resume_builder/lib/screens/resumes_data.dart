import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ResumeData extends StatefulWidget {

  final String name;
  final String email;
  final String achieve;
  final String phone;
  final String address;
  final String designation;
  final String post;
  final String grad;
  final String skill;


  final String project;
  final String experience;

   const ResumeData({Key? key, required this.name, required this.email, required this.achieve, required this.phone, required this.address, required this.designation, required this.post, required this.grad, required this.skill, required this.project, required this.experience, }) : super(key: key);

  @override
  State<ResumeData> createState() => _ResumeDataState();
}

class _ResumeDataState extends State<ResumeData> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar:
    AppBar(centerTitle: true,title: Text("${widget.name} Resume",
      style: TextStyle(fontWeight: FontWeight.bold,fontSize: 25,color: Colors.black),),backgroundColor: Colors.green,),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.name,style: TextStyle(color:Colors.black,fontWeight: FontWeight.bold,fontSize: 30),
                    ),
                    Text(widget.designation,style: TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 25),


                    ),

                  ],),


              ],),


             Text("Location:${widget.address}",style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w400,fontSize: 20),

             ),
             Text("Phone:${widget.phone}",style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w400,fontSize: 20),

             ),
              Text("Phone:${widget.email}",style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w400,fontSize: 20),

              ),
              const Divider(height: 5,thickness: 2,color: Colors.black,),
              const SizedBox(height: 10,),
              const Text("Experience",style:
              TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black, ),),
              Text(widget.experience,style: const TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.black),),
              const SizedBox(height: 10,),
              const Divider(height: 5,thickness: 2,color: Colors.black,),
              const SizedBox(height: 10,),
              const Text("Projects",style:
              TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black, ),),
              Text(widget.project,style: const TextStyle(fontSize: 20,fontWeight: FontWeight.w400,color: Colors.black),),
              const SizedBox(height: 10,),
              const Divider(height: 5,thickness: 2,color: Colors.black,),
              const SizedBox(height: 10,),
              const Text("Education",style:
              TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black, ),),
             Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
               Text(widget.post,style: const TextStyle(fontSize: 20,fontWeight: FontWeight.w400,color: Colors.black),),
               Text(widget.grad,style: const TextStyle(fontSize: 20,fontWeight: FontWeight.w400,color: Colors.black),),
             ],),
              const SizedBox(height: 10,),
              const Divider(height: 5,thickness: 2,color: Colors.black,),
              const SizedBox(height: 10,),
              const Text("Skills",style:
              TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black, ),),
              Text(widget.skill,style: const TextStyle(fontSize: 20,fontWeight: FontWeight.w400,color: Colors.black),),
              const SizedBox(height: 10,),
              const Divider(height: 5,thickness: 2,color: Colors.black,),
              const SizedBox(height: 10,),
              const Text("Achievements",style:
              TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black, ),),
              Text(widget.achieve,style: const TextStyle(fontSize: 20,fontWeight: FontWeight.w400,color: Colors.black),),
              ],),
        ),
      ),);
  }
}

import 'dart:developer';
import 'dart:io';

import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../main.dart';
import '../main.dart';
import '../main.dart';
import '../main.dart';
import '../main.dart';
import 'list_screen.dart';




class AddInformation extends StatefulWidget {
  const AddInformation({Key? key}) : super(key: key);

  @override
  State<AddInformation> createState() => _AddInformationState();
}

class _AddInformationState extends State<AddInformation> {

CollectionReference ref=FirebaseFirestore.instance.collection("user");

  TextEditingController nameCont=TextEditingController();
  TextEditingController phoneCont=TextEditingController();
  TextEditingController emailCont=TextEditingController();
  TextEditingController addressCont=TextEditingController();
  TextEditingController postCont=TextEditingController();
  TextEditingController gradCont=TextEditingController();
  TextEditingController projectCont=TextEditingController();
  TextEditingController experCont=TextEditingController();
  TextEditingController skillsCont=TextEditingController();
  TextEditingController achieveCont=TextEditingController();
  TextEditingController desCont=TextEditingController();


  @override
  Widget build(BuildContext context) {
    var size=MediaQuery.of(context).size;
    return Scaffold(
appBar: AppBar(automaticallyImplyLeading: false,centerTitle: true,backgroundColor: Colors.green,title: Text("Build Your Resume here",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black),),),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 15,),

              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("Basic Information",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.black),),
                    TextField(controller: nameCont,
                      decoration: InputDecoration(hintText: "Enter your Name ",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),
                    TextField(controller: desCont,
                      decoration: InputDecoration(hintText: "Designation ",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),
                    TextField(
                      controller: phoneCont,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(hintText: "Enter your mobile number",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),
                    TextField(controller: emailCont,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(hintText: "Enter your email",

                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),
                    TextField(controller: addressCont,
                      decoration: InputDecoration(hintText: "Enter your Address",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),

                    SizedBox(height: 10,),

                    Text("Education",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.black),),
                    TextField(
                      controller: postCont,
                      maxLines: 2,
                      decoration: InputDecoration(hintText: "Post Graduation",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),
                    TextField(

                      controller: gradCont,
                      maxLines: 2,
                      decoration: InputDecoration(hintText: "Graduation",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),
                    Text("Experience",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.black),),
                    TextField(controller: experCont,
                      maxLines: 5,
                      decoration: InputDecoration(hintText: "Enter your Experience",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),
                    TextField(controller: projectCont,
                      maxLines: 5,
                      decoration: InputDecoration(hintText: "Projects",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),
                    Text("Skills",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.black),),
                    TextField(
                      controller: skillsCont,decoration: InputDecoration(hintText: "Enter your skills",
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 10,),
                    Text("Achievements",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.black),),
                    TextField(
                      controller: achieveCont,decoration: InputDecoration(hintText: "Enter your achievements",
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
                    SizedBox(height: 20,),
                    SizedBox(
                      height: size.height/16,
                      width: size.width,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            elevation: 5,
                            shadowColor: Colors.grey,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            backgroundColor: Colors.black
                        ),
                        onPressed:(){

                          saveData();
                        },
                        child:const Text("Save",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,color: Colors.white),) ,),

                    ),





                  ],),
              )
            ],),),
      ),
    );
  }





  void saveData()async{
    await ref.doc(id.toString()).collection("userdata").add({
      "name":nameCont.text.trim().toString(),
      "email":emailCont.text.trim().toString(),
      "phone":phoneCont.text.trim().toString(),
      "address":addressCont.text.trim().toString(),
      "postG":postCont.text.trim().toString(),
      "grad":gradCont.text.trim().toString(),
      "exp":experCont.text.trim().toString(),
      "project":projectCont.text.trim().toString(),
      "achieve":achieveCont.text.trim().toString(),
      "designation":desCont.text.trim().toString(),
      "skill":skillsCont.text.trim().toString(),
      "id":id


    });



    Navigator.push(context, MaterialPageRoute(builder: (context)=>ListScreen(id: id.toString(),)));
    nameCont.clear();
    emailCont.clear();
    experCont.clear();
    addressCont.clear();
    postCont.clear();
    gradCont.clear();
    skillsCont.clear();
    achieveCont.clear();
    phoneCont.clear();

  }

}





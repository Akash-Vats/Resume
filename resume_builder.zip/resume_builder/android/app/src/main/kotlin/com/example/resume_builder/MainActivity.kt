package com.example.resume_builder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
